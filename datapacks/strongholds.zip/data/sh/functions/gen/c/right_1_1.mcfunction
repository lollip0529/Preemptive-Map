execute if score #pf sh matches 0 run function sh:gen/c/right_1_1_0
execute if score #pf sh matches 1 run function sh:gen/c/right_1_1_1
execute if score #pf sh matches 2 run function sh:gen/c/right_1_1_2
execute if score #pf sh matches 3 run function sh:gen/c/right_1_1_3
