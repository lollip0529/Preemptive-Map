scoreboard players set #mwant sh 2147483647
scoreboard players set #ccx sh -128
function sh:animal/col
scoreboard players set #ccx sh -112
function sh:animal/col
scoreboard players set #ccx sh -96
function sh:animal/col
scoreboard players set #ccx sh -80
function sh:animal/col
scoreboard players set #ccx sh -64
function sh:animal/col
scoreboard players set #ccx sh -48
function sh:animal/col
scoreboard players set #ccx sh -32
function sh:animal/col
scoreboard players set #ccx sh -16
function sh:animal/col
scoreboard players set #ccx sh 0
function sh:animal/col
scoreboard players set #ccx sh 16
function sh:animal/col
scoreboard players set #ccx sh 32
function sh:animal/col
scoreboard players set #ccx sh 48
function sh:animal/col
scoreboard players set #ccx sh 64
function sh:animal/col
scoreboard players set #ccx sh 80
function sh:animal/col
scoreboard players set #ccx sh 96
function sh:animal/col
scoreboard players set #ccx sh 112
function sh:animal/col
scoreboard players set #ccx sh 128
function sh:animal/col
