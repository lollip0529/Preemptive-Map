scoreboard players set #ccz sh -128
function sh:animal/chunk
scoreboard players set #ccz sh -112
function sh:animal/chunk
scoreboard players set #ccz sh -96
function sh:animal/chunk
scoreboard players set #ccz sh -80
function sh:animal/chunk
scoreboard players set #ccz sh -64
function sh:animal/chunk
scoreboard players set #ccz sh -48
function sh:animal/chunk
scoreboard players set #ccz sh -32
function sh:animal/chunk
scoreboard players set #ccz sh -16
function sh:animal/chunk
scoreboard players set #ccz sh 0
function sh:animal/chunk
scoreboard players set #ccz sh 16
function sh:animal/chunk
scoreboard players set #ccz sh 32
function sh:animal/chunk
scoreboard players set #ccz sh 48
function sh:animal/chunk
scoreboard players set #ccz sh 64
function sh:animal/chunk
scoreboard players set #ccz sh 80
function sh:animal/chunk
scoreboard players set #ccz sh 96
function sh:animal/chunk
scoreboard players set #ccz sh 112
function sh:animal/chunk
scoreboard players set #ccz sh 128
function sh:animal/chunk
