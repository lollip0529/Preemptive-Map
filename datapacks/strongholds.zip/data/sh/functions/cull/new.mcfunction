scoreboard players set #found sh -1
function sh:cull/find
execute if score #found sh matches -1 run tellraw @s ["", {"text": "Culling requires the crumbs mod.", "color": "red"}]
execute if score #found sh matches 0 run tellraw @s ["", {"text": "No banked stronghold matches those filters. Relax a setting and try again.", "color": "red"}]
execute if score #found sh matches 1 run scoreboard players set #mines sh 0
execute if score #found sh matches 1 run function sh:menu/refill
execute if score #found sh matches 1 run function sh:generate
