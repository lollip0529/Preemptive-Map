function sh:bank/find
