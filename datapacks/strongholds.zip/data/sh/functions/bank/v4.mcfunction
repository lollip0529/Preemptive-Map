scoreboard players operation #bound sh = #bw sh
function sh:bank/roll
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 9816352
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_2
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 282870
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_4
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 182918
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 182918
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_6
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 543223
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_8
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 106308
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 106308
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_10
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 199690
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 199690
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_12
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 113116
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 113116
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 113116
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_14
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 4782269
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_16
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 646342
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 646342
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_18
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 1599303
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 1599303
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_20
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 374329
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 374329
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 374329
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_22
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 1043346
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 1043346
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_24
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 255332
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 255332
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 255332
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_26
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 235529
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 235529
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 235529
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_28
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 42953
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 42953
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 42953
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 42953
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_30
execute if score #pk sh matches 0 if score #pt sh matches 5 run scoreboard players remove #r sh 100190
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_32
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 8720
execute if score #pk sh matches 0 if score #pt sh matches 5 run scoreboard players remove #r sh 8720
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_34
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 5101
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 5101
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_68
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 1470
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 1470
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 1470
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_70
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 12689
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 12689
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_72
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 2432
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 2432
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 2432
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_74
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 4648
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 4648
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 4648
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_76
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 3348
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 3348
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 3348
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 3348
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_78
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 47081
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 47081
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_80
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 10914
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 10914
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 10914
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_82
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 19316
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 19316
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 19316
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_84
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 2692
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 2692
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 2692
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 2692
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_86
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 20922
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 20922
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 20922
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_88
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 7193
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 7193
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 7193
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 7193
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_90
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 1074
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 1074
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 1074
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 1074
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_92
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 803
execute if score #pk sh matches 0 if score #pt sh matches 2 run scoreboard players remove #r sh 803
execute if score #pk sh matches 0 if score #pt sh matches 3 run scoreboard players remove #r sh 803
execute if score #pk sh matches 0 if score #pt sh matches 4 run scoreboard players remove #r sh 803
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 803
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_94
execute if score #pk sh matches 0 if score #pt sh matches 5 run scoreboard players remove #r sh 294
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 294
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_96
execute if score #pk sh matches 0 if score #pt sh matches 1 run scoreboard players remove #r sh 45
execute if score #pk sh matches 0 if score #pt sh matches 5 run scoreboard players remove #r sh 45
execute if score #pk sh matches 0 if score #pt sh matches 6 run scoreboard players remove #r sh 45
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_98
execute if score #pk sh matches 0 if score #pt sh matches 8 run scoreboard players remove #r sh 11158016
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_257
execute if score #pk sh matches 0 if score #pt sh matches 9 run scoreboard players remove #r sh 22323565
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_513
execute if score #pk sh matches 0 if score #pt sh matches 10 run scoreboard players remove #r sh 14114
execute if score #pk sh matches 0 if score #r sh matches ..-1 run function sh:bank/g4_1024
